from __future__ import unicode_literals
from django.db import models
from bbs.models import UserProfile
# Create your models here.
class Groups(models.Model):
    name=models.CharField(max_length=32)
    brief=models.CharField(max_length=64,blank=True,null=True)
    owner=models.ForeignKey(UserProfile)
    admins=models.ManyToManyField(UserProfile,related_name='admin',blank=True)
    members=models.ManyToManyField(UserProfile,related_name='members',blank=True)
    max_members=models.IntegerField()

    def __unicode__(self):
        return self.name