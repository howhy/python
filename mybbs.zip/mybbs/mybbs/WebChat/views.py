from django.shortcuts import render,HttpResponse
from django.contrib.auth.decorators import login_required
from bbs.views import categorylist
from bbs.models import UserProfile
from models import Groups
import Queue,json,time,os
GLOBAL_MSG_QUEUES={}
@login_required
def webchat(request):
    return render(request,'WebChat/ChatPage.html',{'category_list': categorylist})
def sendmsg(request):
    if request.method=='POST':
        data=request.POST.get('data')
        if data:
            data=json.loads(data)
            data['send_time']=time.time()
            if data['type']=='single':
                if not GLOBAL_MSG_QUEUES.get(int(data['to'])):
                    GLOBAL_MSG_QUEUES[int(data['to'])]=Queue.Queue()
                GLOBAL_MSG_QUEUES[int(data['to'])].put(data)
            elif data['type']=='group':
                group_id=data['contactid']
                group_obj=Groups.objects.get(id=group_id)
                print("---"+group_obj.members.select_related)
                for user in group_obj.members.select_related:
                    if not GLOBAL_MSG_QUEUES.has_key(user.id):
                        GLOBAL_MSG_QUEUES[user.id]=Queue.Queue
                    GLOBAL_MSG_QUEUES[user.id].put(data)
        return HttpResponse('ok')
def getmsg(request):
    if request.user.userprofile.id not in  GLOBAL_MSG_QUEUES:
        GLOBAL_MSG_QUEUES[request.user.userprofile.id]=Queue.Queue()
    Q_obj =GLOBAL_MSG_QUEUES[request.user.userprofile.id]
    Q_count=Q_obj.qsize()
    msg_list = []
    if Q_count>0:
        for msg in range(Q_count):
            msg_list.append(Q_obj.get())
    else:
        try:
            msg_list.append(Q_obj.get(timeout=60))
        except Queue.Empty:
            print('queue is empty...')
    if msg_list:
        name=UserProfile.objects.get(id=msg_list[0]['from']).name
        headimg=UserProfile.objects.get(id=msg_list[0]['from']).head_img
        msg_list[0]['name'] = str(name)
        msg_list[0]['headimg'] = os.path.basename(str(headimg))
        return HttpResponse(json.dumps(msg_list))
