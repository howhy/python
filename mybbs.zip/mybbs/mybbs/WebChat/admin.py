from django.contrib import admin
from WebChat import models
# Register your models here.
class GroupAdmin(admin.ModelAdmin):
    list_display = ('name','owner','max_members')
admin.site.register(models.Groups,GroupAdmin)