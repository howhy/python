#/usr/bin/env python
# -*- coding:utf-8 -*-
from django.shortcuts import render,HttpResponseRedirect,HttpResponse
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.decorators import  login_required
from django.contrib.auth.hashers import PBKDF2PasswordHasher,make_password
from django.db.models import Count
from bbs import  models
from bbs import  articleform
import sys,json,datetime,os
reload(sys)
sys.setdefaultencoding("utf8")
# Create your views here.
categorylist=models.Category.objects.filter(set_as_top_menu=True).order_by('position_index')
@login_required
def index(request):
    categoryobj=models.Category.objects.get(position_index=0)
    arctile=models.Article.objects.all().order_by('id')
    return render(request,'BBS/index.html',{'category_list':categorylist,'category_obj':categoryobj,'arctile_obj':arctile})
def category(request,id):
    category=models.Category.objects.get(id=id)
    if category.id==1:
        arctile=models.Article.objects.filter(status='published')
    else:
        arctile=models.Article.objects.filter(category=id,status='published').order_by('id')
    return render(request, 'BBS/index.html', {'category_list': categorylist, 'category_obj': category,'arctile_obj':arctile})
def acclogin(request):
    arctile = models.Article.objects.filter(status='published')
    print(request.POST)
    if request.method=='POST':
        user=authenticate(username=request.POST.get('username'),password=request.POST.get('password'))
        if user and user.is_active:
            login(request,user)
            return HttpResponseRedirect(request.GET.get('next') or '/bbs/')
        else:
            login_err='用户名或密码错误!'
            return HttpResponse("<script>alert('%s');window.location.href='/bbs/'</script>" %login_err)
    return render(request, 'BBS/index.html', {'category_list':categorylist,'arctile_obj':arctile})
def register(request):
    if request.method=='POST':
        file_obj=request.FILES.get('headimg')
        user_obj=models.User.objects.create(username=request.POST.get('username'),password=make_password(request.POST.get('regpassword')),email=request.POST.get('email'))
        models.UserProfile.objects.create(user_id=user_obj.id,name=request.POST.get('username'),head_img='uploads/%s'%file_obj.name)
        with open('statics/uploads/%s'% file_obj.name,'wb+') as imgfile:
            for chunk in file_obj.chunks():
               imgfile.write(chunk)
        return HttpResponseRedirect(request.GET.get('next') or '/bbs/')
def acclogout(request):
    logout(request)
    return HttpResponseRedirect('/bbs/')
def articledetail(request,id):
    article_detail=models.Article.objects.get(id=id)
    comment_obj=models.Comment.objects.filter(article_id=id,comment_type=1)
    thumb_obj=models.Comment.objects.filter(article_id=id,comment_type=2)
    type_count={'comment':comment_obj.count(),'thumb':thumb_obj.count()}
    # def buildtree():
    #     dict = {}
    #     for com in comment_obj:
    #         addnode(dict, com)
    #     return dict
    #
    # def addnode(kv, objs):
    #     if objs.parent_comment_id is None:
    #         kv[objs.id] = {}
    #     else:
    #         for k, v in kv.items():
    #             if k == objs.parent_comment_id:
    #                 kv[k][objs.id] = {}
    #             else:
    #                 addnode(v, objs)
    #
    # def gethtml(dic):
    #     strhtml = ""
    #     for k, v in dic.items():
    #         strhtml += "<ul><li class=''><span title='Collapse this branch'>%s</span><span style='color:#bbb;font-size:small;padding-left:5px'> %s   %s</span>" % ( models.Comment.objects.get(id=k).comment, (models.Comment.objects.get(id=k).date).strftime('%Y-%m-%d %H:%M:%S'),models.Comment.objects.get(id=k).user)
    #         strhtml += gethtml(v) + "</li></ul>"
    #     return strhtml
    #return render(request,'BBS/articledetail.html',{'article':article_detail,'category_list':categorylist,'type_count':type_count,'comment_list':gethtml(buildtree())})
    return render(request,'BBS/articledetail.html',{'article':article_detail,'category_list':categorylist,'type_count':type_count,})
def postcomment(request,id):
    if request.method=='POST':
        models.Comment.objects.create(comment_type=request.POST.get('comment_type'),comment=request.POST.get('comment_content'),article_id=id,parent_comment_id=request.POST.get('parent_comment_id') or None,user_id=request.user.userprofile.id)
        thumbs_count = models.Comment.objects.filter(comment_type=2, article_id=id).count()
        comment_count = models.Comment.objects.filter(comment_type=1, article_id=id).count()
        return HttpResponse(json.dumps({'ret':{'thumbcount':thumbs_count,'commentcount':comment_count}}))
def postarticle(request):
    if request.method=='GET':
        article_form=articleform.ArticleModelForm()
        return render(request,'BBS/newarticle.html',{'category_list':categorylist,'articleform':article_form})
    elif request.method=="POST":
        article_form=articleform.ArticleModelForm(request.POST,request.FILES)
        if article_form.is_valid():
            data=article_form.cleaned_data
            data['author_id']=request.user.userprofile.id
            data['pub_date']=datetime.datetime.now()
            article_obj=models.Article(**data)
            article_obj.save()
            return  HttpResponseRedirect('/bbs/')
        else:
            return render(request, 'bbs/newarticle.html', {'article_form': article_form})
def getcomment(request,id):
    comment_obj = models.Comment.objects.filter(article_id=id, comment_type=1)
    def buildtree():
        dict = {}
        for com in comment_obj:
            addnode(dict, com)
        return dict
    def addnode(kv, objs):
        if objs.parent_comment_id is None:
            kv[objs.id] = {}
        else:
            for k, v in kv.items():
                if k == objs.parent_comment_id:
                    kv[k][objs.id] = {}
                else:
                    addnode(v, objs)
    def gethtml(dic):
        strhtml = ""
        for k, v in dic.items():
            strhtml += "<ul><li class='parent_li'><span title='Collapse this branch'><img src='/static/%s' style='width:24px;height:24px'/> %s</span><span style='color:#bbb;font-size:small;padding:0px 10px'> %s     %s</span><div style='color:#339933;font-size:smaller' class='glyphicon glyphicon-comment add-comment' commentid=%s aria-hidden='true'>评论</div>" % (os.path.basename(str(models.UserProfile.objects.get(id=models.Comment.objects.get(id=k).user_id).head_img)),models.Comment.objects.get(id=k).comment,(models.Comment.objects.get(id=k).date).strftime('%Y-%m-%d %H:%M:%S'),models.Comment.objects.get(id=k).user,k)
            strhtml += gethtml(v) + " </li></ul>"
        return strhtml
    strhtml=gethtml(buildtree())
    return HttpResponse(strhtml)


