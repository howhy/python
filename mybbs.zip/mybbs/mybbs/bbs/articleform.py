#/usr/bin/env python
# -*- coding:utf-8 -*-
from bbs import models
from django.forms import ModelForm
class ArticleModelForm(ModelForm):
    class Meta:
        model=models.Article
        exclude=('author','pub_date','priority')
    def __init__(self,*args,**kwargs):
        super(ArticleModelForm,self).__init__(*args,**kwargs)
        #self.fields['title'].widget.attrs['class']=
        for field_name in self.base_fields:
            field=self.base_fields[field_name]
            field.widget.attrs.update({'class':'form-control'})
