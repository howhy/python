from django import  template
from django.utils.html import format_html
import os
register=template.Library()
@register.filter
def truncate_path(img_url):
    return os.path.basename(img_url.name)
@register.simple_tag
def comment_count(article_obj):
    query_set=article_obj.comment_set.select_related()
    type_count = {'comment': query_set.filter(comment_type=1).count(), 'thumb': query_set.filter(comment_type=2).count()}
    return type_count
