from django.contrib import admin
from bbs import models
# Register your models here.

class userProfileAdmin(admin.ModelAdmin):
    list_display = ('user','name','signature')
class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title','category','author','status','pub_date')
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name','brief','position_index')
admin.site.register(models.UserProfile,userProfileAdmin)
admin.site.register(models.Article,ArticleAdmin)
admin.site.register(models.Category,CategoryAdmin)
admin.site.register(models.Comment)
