#!/bin/usr/env python
#-*-coding:utf8-*-
from django.db import models
from django.contrib.auth.models import  User
from django.core.exceptions import ValidationError
import datetime
# Create your models here.
#用户表
class UserProfile(models.Model):
    user=models.OneToOneField(User)
    name=models.CharField(max_length=32)
    signature=models.CharField(max_length=32)
    head_img=models.ImageField(blank=True,null=True,upload_to='statics/uploads')
    friends=models.ManyToManyField('self',related_name="myfriend",blank=True,null=True)
    #groups=models.ManyToManyField(Groups,related_name='mygroup',blank=True,null=True)
    def __str__(self):
        return self.name
#文章分类表
class Category(models.Model):
    name=models.CharField(max_length=64)
    brief=models.CharField(max_length=64)
    set_as_top_menu=models.BooleanField(default=False)
    position_index=models.IntegerField()
    admins=models.ManyToManyField(UserProfile,blank=True)

    def __str__(self):
        return self.name

#文章表
class Article(models.Model):
    title=models.CharField(max_length=64)
    brief=models.CharField(max_length=64)
    category=models.ForeignKey(Category)
    article_img=models.ImageField(u'文章标题图片',upload_to='statics/uploads')
    content=models.TextField(u'文章内容')
    author=models.ForeignKey(UserProfile)
    #author = models.ForeignObject()
    pub_date=models.DateTimeField(blank=True,null=True)
    last_modify=models.DateTimeField(auto_now=True)
    priority=models.IntegerField(default=1)
    status_choices=(( 'draft',u'草稿'),
                    ('published',u'发布'),
                    ('hidden',u'隐藏'))
    status=models.CharField(choices=status_choices,default='published',max_length=32)
    def clean(self):
        if self.status=='draft' and self.pub_date is not None:
            raise ValidationError('drafe status can not have publisher date')
        if self.status=='published' and  self.pub_date is None:
            self.pub_date=datetime.datetime.now()

    def __str__(self):
        return self.title

#评论表
class Comment(models.Model):
    article=models.ForeignKey(Article,verbose_name=u'所属文章')
    parent_comment=models.ForeignKey('self',related_name='my_children',blank=True,null=True)
    type_choices=((1,u'评论'),
                  (2,u'点赞'))
    comment_type=models.IntegerField(default=1)
    user=models.ForeignKey(UserProfile)
    comment=models.TextField(blank=True,null=True)
    date=models.DateTimeField(auto_now_add=True)
    def clean(self):
        if self.type_choices==1 and self.comment is None:
            raise  ValidationError('comment can not is blank')

    def __str__(self):
        return self.comment



